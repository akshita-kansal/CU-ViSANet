# GENERATED VERSION FILE
# TIME: Fri Mar  1 06:34:43 2024
__version__ = '0.1.0'
__gitsha__ = 'unknown'
version_info = (0, 1, 0)
